const o={HarmonicMotion:{topic:"Harmonic Motion",questions:"HMQuestions"}};export{o as t};

const o={HarmonicMotion:{topic:"Simple Harmonic Motion",questions:"HMQuestions"}};export{o as t};

import{a as t}from"../chunks/entry.D3O7tIDd.js";export{t as start};

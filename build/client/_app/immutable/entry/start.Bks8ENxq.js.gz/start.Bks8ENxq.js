import{a as t}from"../chunks/entry.BvEPwwOM.js";export{t as start};

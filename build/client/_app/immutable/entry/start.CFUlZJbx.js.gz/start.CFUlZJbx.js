import{a as t}from"../chunks/entry.zgnK7Oan.js";export{t as start};

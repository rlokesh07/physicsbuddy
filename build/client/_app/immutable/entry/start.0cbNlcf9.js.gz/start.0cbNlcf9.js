import{a as t}from"../chunks/entry.C9235puh.js";export{t as start};

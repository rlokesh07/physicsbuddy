import{a as t}from"../chunks/entry.C94gmttt.js";export{t as start};

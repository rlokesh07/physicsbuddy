import{a as t}from"../chunks/entry.C-lzaQTI.js";export{t as start};

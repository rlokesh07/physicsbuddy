import{a as t}from"../chunks/entry.DqVaRFZD.js";export{t as start};

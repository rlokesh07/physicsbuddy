import{a as t}from"../chunks/entry.DtQj_Jb6.js";export{t as start};

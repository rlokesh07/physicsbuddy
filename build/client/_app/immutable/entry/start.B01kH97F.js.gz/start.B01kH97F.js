import{a as t}from"../chunks/entry.DVdNS1uR.js";export{t as start};

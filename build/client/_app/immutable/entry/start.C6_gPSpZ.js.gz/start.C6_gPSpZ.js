import{a as t}from"../chunks/entry.DiOR7WUu.js";export{t as start};

import{a as t}from"../chunks/entry.B2SKC1Vo.js";export{t as start};

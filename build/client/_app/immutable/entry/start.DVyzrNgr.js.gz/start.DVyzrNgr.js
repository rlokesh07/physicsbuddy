import{a as t}from"../chunks/entry.6uwx2wIw.js";export{t as start};

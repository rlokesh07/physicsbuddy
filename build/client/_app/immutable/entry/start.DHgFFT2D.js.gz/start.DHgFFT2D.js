import{a as t}from"../chunks/entry.Bky_Z9RX.js";export{t as start};

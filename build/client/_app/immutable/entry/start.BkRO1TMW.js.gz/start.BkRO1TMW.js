import{a as t}from"../chunks/entry.DuOGgDmH.js";export{t as start};

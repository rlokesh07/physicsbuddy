import{a as t}from"../chunks/entry.Dpy-Qo2Y.js";export{t as start};

import{a as t}from"../chunks/entry.JSWGBekg.js";export{t as start};

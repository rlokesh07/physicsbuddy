import{a as t}from"../chunks/entry.BB-Y5jq6.js";export{t as start};

import{a as t}from"../chunks/entry.ZzuS7UE5.js";export{t as start};

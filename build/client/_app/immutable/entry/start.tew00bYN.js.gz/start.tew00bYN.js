import{a as t}from"../chunks/entry.DG7SxtS1.js";export{t as start};

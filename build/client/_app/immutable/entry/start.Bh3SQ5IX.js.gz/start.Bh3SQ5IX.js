import{a as t}from"../chunks/entry.DFOA26m_.js";export{t as start};
